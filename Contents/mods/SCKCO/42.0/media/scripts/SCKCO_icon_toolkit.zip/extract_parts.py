# Lay vehicle part meshes flat as world items, matching the existing SCKCO WorldItems recipe:
# one mesh, baked world transform, outward face rotated to +Z, XY centred, resting on Z=0,
# single UV layer "UVMap", no armature/weights/materials, Blender default FBX export.
# usage: python extract_parts.py <media> <jobs.json>   or   blender -b -P extract_parts.py -- <media> <jobs.json>
# job: {"vehicle": "vehicles/Ford/Vehicle_FordTaurus86_SC", "obj": "Hood_obj",
#       "out": "WorldItems/Ford/Taurus/FordTaurusHood_WorldItem", "up_out": true, "flip": false, "spin": 0, "keep_pose": false}
import bpy, sys, json, math, os
import numpy as np
import mathutils


def load_vehicle(path):
    bpy.ops.wm.read_factory_settings(use_empty=True)
    bpy.ops.import_scene.fbx(filepath=path)
    meshes = {o.name: o for o in bpy.context.scene.objects if o.type == 'MESH' and len(o.data.vertices)}
    allpts = np.array([o.matrix_world @ v.co for o in meshes.values() for v in o.data.vertices])
    centre = (allpts.min(0) + allpts.max(0)) / 2
    return meshes, mathutils.Vector(centre)


def flat_rotation(pts, part_centre, veh_centre, up_out=False):
    c = pts - pts.mean(0)
    w, v = np.linalg.eigh(c.T @ c)
    n = mathutils.Vector(v[:, 0])                      # least-variance axis = panel normal
    out = mathutils.Vector((0, 0, 1)) if up_out else part_centre - veh_centre
    if n.dot(out) < 0:
        n = -n                                         # outward face up
    return n.rotation_difference(mathutils.Vector((0, 0, 1))).to_matrix().to_4x4()


def extract(meshes, veh_centre, job):
    src = meshes.get(job['obj']) if job.get('obj') else (next(iter(meshes.values())) if len(meshes) == 1 else None)
    if src is None:
        raise KeyError(f"{job['obj']} not in {os.path.basename(job['fbx'])}: {sorted(meshes)}")
    me = src.data.copy()
    me.transform(src.matrix_world)
    while len(me.uv_layers) > 1:
        me.uv_layers.remove(me.uv_layers[-1])
    if me.uv_layers:
        me.uv_layers[0].name = 'UVMap'
    me.materials.clear()

    pts = np.array([v.co[:] for v in me.vertices])
    pc = mathutils.Vector(((pts.min(0) + pts.max(0)) / 2).tolist())
    if job.get('keep_pose'):
        R = mathutils.Matrix.Identity(4)                # standalone attachments keep their modelled pose
    else:
        R = flat_rotation(pts, pc, veh_centre, job.get('up_out', False))
    if job.get('flip'):
        R = mathutils.Matrix.Rotation(math.pi, 4, 'Y') @ R
    if job.get('spin'):
        R = mathutils.Matrix.Rotation(math.radians(job['spin']), 4, 'Z') @ R
    me.transform(R)
    pts = np.array([v.co[:] for v in me.vertices])
    mn, mx = pts.min(0), pts.max(0)
    me.transform(mathutils.Matrix.Translation((-(mn[0] + mx[0]) / 2, -(mn[1] + mx[1]) / 2, -mn[2])))
    me.update()

    for o in list(bpy.data.objects):
        if o.users_collection:
            o.select_set(False)
    name = src.name
    src.name = name + '__src'
    ob = bpy.data.objects.new(name, me)
    bpy.context.scene.collection.objects.link(ob)
    ob.select_set(True)
    bpy.context.view_layer.objects.active = ob
    os.makedirs(os.path.dirname(job['out']), exist_ok=True)
    bpy.ops.export_scene.fbx(filepath=job['out'], use_selection=True, object_types={'MESH'},
                             mesh_smooth_type='FACE', add_leaf_bones=False, bake_anim=False)
    bpy.data.objects.remove(ob)
    src.name = name


argv = sys.argv[sys.argv.index('--') + 1:] if '--' in sys.argv else sys.argv[1:]
media, jobs = argv[0], json.load(open(argv[1], encoding='utf-8'))
for job in jobs:
    job['fbx'] = os.path.join(media, 'models_X', job['vehicle'] + ('' if job['vehicle'].lower().endswith('.fbx') else '.fbx'))
    job['out'] = os.path.join(media, 'models_X', job['out'] + ('' if job['out'].lower().endswith('.fbx') else '.fbx'))
    if not os.path.exists(job['fbx']):
        raise FileNotFoundError(job['fbx'])
cache = {}
for job in sorted(jobs, key=lambda j: j['fbx']):
    if job['fbx'] not in cache:
        cache.clear()
        cache[job['fbx']] = load_vehicle(job['fbx'])
    meshes, centre = cache[job['fbx']]
    extract(meshes, centre, job)
    print('OK', os.path.relpath(job['out'], media))
