# SCKCO icon renderer: FBX world item + vehicle texture -> 30x32 PZ inventory icon.
# Runs under the bpy pip module (python render_icons.py ...) or Blender (blender -b -P render_icons.py -- ...).
import argparse, json, math, os, re, sys, tempfile, hashlib

import bpy
import mathutils
from PIL import Image, ImageDraw

RW, RH = 240, 256          # render size, 8x the icon so the downscale anti-aliases
OW, OH = 30, 32            # vanilla/SCKCO icon size
GLASS = (120, 155, 190)    # tint for low-alpha glass texels
FIT_MARGIN = 1.25          # ortho padding around the part
VARIANTS = {               # preview mode camera presets
    'top': {},
    'flip': {'flip': True},
    'lowf': {'elev': 20},
    'lowb': {'elev': 20, 'azim': 155},
}


def setup_scene():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    sc = bpy.context.scene
    sc.render.engine = 'CYCLES'
    sc.cycles.device = 'CPU'
    sc.cycles.samples = 24
    sc.cycles.use_denoising = False
    sc.render.resolution_x, sc.render.resolution_y = RW, RH
    sc.render.film_transparent = True
    sc.render.image_settings.file_format = 'PNG'
    sc.render.image_settings.color_mode = 'RGBA'
    sc.view_settings.view_transform = 'Standard'
    w = bpy.data.worlds.new('W')
    sc.world = w
    w.use_nodes = True
    w.node_tree.nodes['Background'].inputs[1].default_value = 0.9
    sun = bpy.data.objects.new('Sun', bpy.data.lights.new('Sun', 'SUN'))
    sun.data.energy = 2.5
    sun.rotation_euler = (math.radians(35), math.radians(15), math.radians(-40))
    sc.collection.objects.link(sun)
    return sc


def opaque_texture(tex_path):
    # vehicle sheets keep glass as low-alpha texels; flatten onto a glass tint so windows stay visible
    out = os.path.join(tempfile.gettempdir(), 'sckco_icon_' + hashlib.md5(tex_path.encode()).hexdigest() + '.png')
    if not os.path.exists(out) or os.path.getmtime(out) < os.path.getmtime(tex_path):
        src = Image.open(tex_path).convert('RGBA')
        bg = Image.new('RGBA', src.size, GLASS + (255,))
        bg.alpha_composite(src)
        bg.save(out)
    return out


def textured_material(tex_path):
    m = bpy.data.materials.new('M')
    m.use_nodes = True
    nt = m.node_tree
    bsdf = nt.nodes['Principled BSDF']
    img = nt.nodes.new('ShaderNodeTexImage')
    img.image = bpy.data.images.load(opaque_texture(tex_path))
    img.interpolation = 'Closest'
    nt.links.new(img.outputs['Color'], bsdf.inputs['Base Color'])
    bsdf.inputs['Roughness'].default_value = 0.6
    return m


def render(fbx, tex, out, elev=50, azim=-25, roll=0, flip=False):
    sc = setup_scene()
    bpy.ops.import_scene.fbx(filepath=fbx)
    meshes = [o for o in sc.objects if o.type == 'MESH']
    if not meshes:
        raise RuntimeError('no mesh in ' + fbx)
    mat = textured_material(tex)
    for o in meshes:
        o.data.materials.clear()
        o.data.materials.append(mat)
        if flip:
            o.matrix_world = mathutils.Matrix.Rotation(math.pi, 4, 'Y') @ o.matrix_world
    bpy.context.view_layer.update()

    pts = [o.matrix_world @ v.co for o in meshes for v in o.data.vertices]
    mn = mathutils.Vector([min(p[i] for p in pts) for i in range(3)])
    mx = mathutils.Vector([max(p[i] for p in pts) for i in range(3)])
    ctr = (mn + mx) / 2
    rad = max((p - ctr).length for p in pts)

    # world items lie flat on XY at cm scale, so near/far clip must scale with the part
    el, az = math.radians(elev), math.radians(azim)
    d = mathutils.Vector((math.cos(el) * math.sin(az), -math.cos(el) * math.cos(az), math.sin(el)))
    cam = bpy.data.objects.new('Cam', bpy.data.cameras.new('Cam'))
    cam.data.type = 'ORTHO'
    cam.location = ctr + d * rad * 10
    cam.rotation_euler = (-d).to_track_quat('-Z', 'Y' if abs(d.z) < 0.99 else 'X').to_euler()
    cam.rotation_euler.rotate_axis('Z', math.radians(roll))
    cam.data.clip_start = rad * 0.5
    cam.data.clip_end = rad * 30
    sc.collection.objects.link(cam)
    sc.camera = cam
    bpy.context.view_layer.update()

    inv = cam.matrix_world.inverted()
    cp = [inv @ p for p in pts]
    xs = [p.x for p in cp]
    ys = [p.y for p in cp]
    w, h = max(xs) - min(xs), max(ys) - min(ys)
    aspect = RW / RH
    cam.data.ortho_scale = (w if w >= h * aspect else h) * FIT_MARGIN
    cam.data.shift_x = ((max(xs) + min(xs)) / 2) / cam.data.ortho_scale
    cam.data.shift_y = ((max(ys) + min(ys)) / 2) / cam.data.ortho_scale

    big = out + '.big.png'
    sc.render.filepath = big
    bpy.ops.render.render(write_still=True)
    os.makedirs(os.path.dirname(os.path.abspath(out)), exist_ok=True)
    Image.open(big).convert('RGBA').resize((OW, OH), Image.LANCZOS).save(out)
    os.remove(big)


def resolve(media, job):
    fbx = os.path.join(media, 'models_X', job['fbx'])
    if not fbx.lower().endswith('.fbx'):
        fbx += '.fbx'
    tex = os.path.join(media, 'textures', job['tex'])
    if not tex.lower().endswith('.png'):
        tex += '.png'
    for p in (fbx, tex):
        if not os.path.exists(p):
            raise FileNotFoundError(p)
    return fbx, tex


def contact_sheet(rows, path, scale=4):
    cw, ch = OW * scale + 10, OH * scale + 6
    lw = 190
    W = Image.new('RGBA', (lw + cw * len(VARIANTS), ch * len(rows)), (80, 80, 80, 255))
    d = ImageDraw.Draw(W)
    for x, v in enumerate(VARIANTS):
        d.text((lw + x * cw + 4, 0), v, fill=(255, 255, 255, 255))
    for y, (name, files) in enumerate(rows):
        d.text((4, y * ch + ch // 2), name, fill=(255, 230, 0, 255))
        for x, f in enumerate(files):
            W.alpha_composite(Image.open(f).resize((OW * scale, OH * scale), Image.NEAREST), (lw + x * cw, y * ch + 4))
    W.save(path)


def apply_icons(media, jobs):
    want = {it: j['icon'] for j in jobs for it in j.get('items', [])}
    found = {}
    item_re = re.compile(rb'\bitem[ \t]+(\w+)\s*\{(.*?)\}', re.S)
    icon_re = re.compile(rb'(\n[ \t]*Icon[ \t]*=[ \t]*)[^,\r\n]+')
    for root, _, files in os.walk(os.path.join(media, 'scripts')):
        for fn in files:
            if not fn.lower().endswith('.txt'):
                continue
            p = os.path.join(root, fn)
            src = open(p, 'rb').read()

            def fix(m):
                name = m.group(1).decode()
                if name not in want:
                    return m.group(0)
                body, n = icon_re.subn(lambda mm: mm.group(1) + want[name].encode(), m.group(2), count=1)
                if n != 1:
                    raise RuntimeError(f'{name} in {p} has no Icon line')
                found[name] = found.get(name, 0) + 1
                s = m.start(2) - m.start(0)
                return m.group(0)[:s] + body + m.group(0)[s + len(m.group(2)):]

            dst = item_re.sub(fix, src)
            if dst != src:
                open(p, 'wb').write(dst)
                print('updated', os.path.relpath(p, media))
    missing = sorted(set(want) - set(found))
    if missing:
        raise RuntimeError('items not found in scripts: ' + ', '.join(missing))
    print(f'{sum(found.values())} item blocks repointed')


def main():
    argv = sys.argv[sys.argv.index('--') + 1:] if '--' in sys.argv else sys.argv[1:]
    ap = argparse.ArgumentParser(description='Render SCKCO inventory icons from WorldItems FBX meshes.')
    ap.add_argument('media', help='path to ...\\SCKCO\\42.0\\media')
    ap.add_argument('jobs', help='jobs .json (see example_jobs.json)')
    ap.add_argument('--preview', metavar='DIR', help='render all camera variants + contact sheet to DIR instead of writing icons')
    ap.add_argument('--apply-icons', action='store_true', help='also repoint each job\'s items to its icon in scripts/')
    ap.add_argument('--only', help='regex; only jobs whose icon matches')
    a = ap.parse_args(argv)

    jobs = json.load(open(a.jobs, encoding='utf-8'))
    if a.only:
        jobs = [j for j in jobs if re.search(a.only, j['icon'])]

    if a.preview:
        rows = []
        for j in jobs:
            fbx, tex = resolve(a.media, j)
            name = j['icon'].split('/')[-1]
            files = []
            for v, opts in VARIANTS.items():
                f = os.path.join(a.preview, f'{name}_{v}.png')
                render(fbx, tex, f, **opts)
                files.append(f)
            rows.append((name, files))
        sheet = os.path.join(a.preview, '_sheet.png')
        contact_sheet(rows, sheet)
        print('preview sheet:', sheet)
        return

    for j in jobs:
        fbx, tex = resolve(a.media, j)
        out = os.path.join(a.media, 'textures', 'Item_' + j['icon'] + '.png')
        opts = {k: j[k] for k in ('elev', 'azim', 'roll', 'flip') if k in j}
        render(fbx, tex, out, **opts)
        print('OK', os.path.relpath(out, a.media))
    if a.apply_icons:
        apply_icons(a.media, jobs)


if __name__ == '__main__':
    main()
