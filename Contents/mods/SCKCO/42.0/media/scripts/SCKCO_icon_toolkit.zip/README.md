# SCKCO Icon Toolkit

Renders Project Zomboid B42 inventory icons (30x32 RGBA) for vehicle parts. `render_vehicle_icons.py`
renders from the vehicle FBX (preferred, see below); `render_icons.py` renders from the
`models_X/WorldItems` FBX meshes and the vehicle's texture sheet, in the same 3/4 top-down
style as the existing `Item_SCKCO/Parts` icons. Optionally repoints the matching items' `Icon =`
lines in `scripts/`.

## Requirements

Either one:

- **Blender** (4.x/5.x): run through it, no install needed
  `blender -b -P render_icons.py -- <media> <jobs.json> [options]`
- **bpy pip module** (it needs the exact Python version that bpy build targets; bpy 5.x needs Python 3.13):
  `pip install bpy pillow`, then `python render_icons.py <media> <jobs.json> [options]`

Pillow is needed either way. Under Blender, install it into Blender's bundled Python.

## Jobs file

A JSON list. Paths are relative to `media/models_X` and `media/textures`, and the extension is optional:

    {
      "icon":  "SCKCO/Parts/Jeep/JeepCJ7Hood",
      "fbx":   "WorldItems/Jeep/CJ7/CJ7Hood_WorldItem",
      "tex":   "Vehicles/JeepCJ7/Vehicle_JeepCJ7_WhiteDual",
      "items": ["JeepCJ7HoodSC2"]
    }

- `icon`: the item's `Icon =` value. The file is written to `textures/Item_<icon>.png`.
- `items`: item names to repoint when `--apply-icons` is used (optional).
- Camera overrides (optional):
  - `elev`: degrees, default 50
  - `azim`: degrees, default -25
  - `roll`: degrees, default 0
  - `flip`: boolean, renders the underside

`example_jobs.json` is the full Accord / Rabbit / Cherokee / CJ7 / M35 / Firecoach / PRC set,
with the overrides that were used for it.

## Usage

Pick angles first. This renders every job from 4 camera presets (`top`, `flip`, `lowf`, `lowb`)
into a scratch folder, plus `_sheet.png` to compare them side by side. Nothing in the mod is touched:

    python render_icons.py "...\SCKCO\42.0\media" jobs.json --preview C:\temp\icons

Then put the overrides you liked in the jobs file and render for real:

    python render_icons.py "...\SCKCO\42.0\media" jobs.json --apply-icons

`--only <regex>` limits the run to jobs whose `icon` matches, e.g. `--only CJ7`.

## Notes

- World items are modelled flat on the XY plane at centimetre scale. The camera auto-fits each
  part and scales its clip range to the part, so tiny meshes don't render blank.
- Glass texels have low alpha in the vehicle sheets. They are flattened onto a blue-grey tint so
  windows and windshields read as glass instead of vanishing.
- Armor pieces are rendered with whatever texture the job names. If a vehicle has a separate armor
  sheet (e.g. `JeepCJ7ArmorParts1`), point those jobs at it.
- `--apply-icons` errors out, with the item names, if any listed item can't be found or has no
  `Icon` line. Each file's existing line endings are kept.
- Default parts look best from `top`. Bumpers and soft tops usually look better from `flip` or `lowf`.

## Icons from the vehicle mesh (render_vehicle_icons.py), preferred

Renders the part where it sits in the vehicle FBX, so it always comes out the way it's mounted:
- doors, windows and windshields: outside face nearly head-on, upright, vehicle front on the right;
- hoods, trunk lids and roofs: top face, vehicle front at the top;
- solid parts (bumpers, tops, frames): 3/4 from above on their outward side.

A slight 3/4 offset (elev 22, azim 18, roll -10) matches the hand-made icons. Glass renders flat navy.

    python render_vehicle_icons.py "...\SCKCO\42.0\media" vehicle_icon_jobs.json
    python render_vehicle_icons.py "...\SCKCO\42.0\media" vehicle_icon_jobs.json --only Radios --out-dir C:\temp\icons --big

- `--only <regex>`: only jobs whose `icon` matches.
- `--out-dir <dir>`: write `Item_<icon>.png` there instead of into `media/textures` (for previewing).
- `--big`: also save the 240x256 render as `*_big.png`.

`vehicle_icon_jobs.json` is the full set of 236 part icons, with the overrides that were used for it.
Paths are relative to `media/models_X` and `media/textures`, and the extension is optional:

    {"icon": "SCKCO/Parts/Jeep/JeepCJ7Door", "vehicle": "vehicles/Jeep/Vehicle_JeepCJ7_SC",
     "obj": "FrontLeftDoor_obj", "obj_right": "FrontRightDoor_obj", "tex": "Vehicles/JeepCJ7/Vehicle_JeepCJ7_WhiteDual"}

    {"icon": "SCKCO/Parts/Radios/RT524", "standalone": "WorldItems/Radios/RT524_WorldItem",
     "tex": "Vehicles/M151A2/Vehicle_HM151_Radio", "view": [-1, 0, 0], "elev": 30, "azim": 30, "roll": 0}

- `vehicle` + `obj`: the vehicle FBX and the mesh object to render.
- `obj_right`: preferred when it exists, so side parts face front-right.
- `standalone`: render a world-item FBX on its own instead, for parts that have no vehicle mesh (radios, toppers).
- `tex`: use the texture the vehicle script's `model` block declares for that mesh.
  If a vehicle has a separate armor sheet, point its armor jobs at that sheet.
- Overrides (optional):
  - `elev`, `azim`, `roll`: degrees, replacing the defaults above;
  - `view`: `[x, y, z]` model-space direction the camera sits in (e.g. the radio's front face);
    with it, positive `elev` looks from above and positive `azim` turns the part to the right;
  - `up`: `[x, y, z]` image-up when using `view` (default `[0, 0, 1]`);
  - `flip_up`: turns the icon upside down;
  - `solid`: forces the 3/4 solid view on a part detected as a flat panel;
  - `glass`: `true`/`false` overrides the name-based glass detection
    (`window`/`windshield` without `armor`/`frame`).

Missing files or a missing `obj` raise an error naming the path or listing the meshes that do exist.

## Making world items from a vehicle (extract_parts.py)

Pulls a part mesh out of a vehicle FBX and saves it as a world-item FBX the same way the existing
`WorldItems` were made:
- single mesh, original object name kept;
- outward face laid flat on +Z, centred on XY, resting on Z=0;
- one `UVMap`, no armature, weights or materials;
- Blender default binary FBX export (Y-up, unit scale 1).

    python extract_parts.py "...\SCKCO\42.0\media" parts.json

    [
      {"vehicle": "vehicles/Mercedes/Vehicle_Mercedes280_SC", "obj": "Hood_obj",
       "out": "WorldItems/Mercedes/Mercedes280Hood_WorldItem", "up_out": true}
    ]

- `obj` is the mesh object inside the vehicle FBX. The vehicle script's `mesh = file|object` lines tell you which.
- Use the right-hand or front object where there's a choice (`FrontRightDoor_obj`), matching the existing world items.
- Outward is worked out as "away from the vehicle's centre". Objects named like hoods, roofs, tops
  and tarps use straight up instead, because tall vehicles put the hood below their centre and would
  otherwise lay it upside down. Force either way with `"up_out": true/false`.
- `flip` turns the part over and `spin` rotates it in degrees around Z, if the automatic pose is wrong.
- `"keep_pose": true` skips laying the part flat, for standalone attachment models like roof toppers. `obj` can
  be left out when the FBX holds a single mesh.

Then add a `model ..._WorldItem` block to `SC_worlditems.txt`, set the item's `WorldStaticModel`, and
render its icon with `render_icons.py`.
