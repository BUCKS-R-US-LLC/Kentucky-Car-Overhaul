# Render inventory icons (30x32 RGBA) from the part mesh inside its vehicle FBX.
# Vehicle space gives the real mounting orientation, so panels come out upright and front-right.
#   blender -b -P render_vehicle_icons.py -- <media> <jobs.json> [--only REGEX] [--out-dir DIR] [--big]
#   python render_vehicle_icons.py <media> <jobs.json> [...]          (bpy pip module)
import bpy, sys, json, math, os, re, hashlib, tempfile
import numpy as np
import mathutils
from PIL import Image

RW, RH, OW, OH = 240, 256, 30, 32
GLASS_RGB = (0.05, 0.12, 0.25)
TINT = (120, 155, 190, 255)                  # shows through low-alpha glass texels in the sheets
UP_PARTS = ('hood', 'roof', 'top', 'tarp', 'trunk')
LYING_PARTS = ('hood', 'trunk', 'roof')
# offsets that give the slight 3/4 look of the hand-made icons
ELEV, AZIM, ROLL = 22.0, 18.0, -10.0
FIT = 1.18


def scene():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    sc = bpy.context.scene
    sc.render.engine = 'CYCLES'; sc.cycles.device = 'CPU'; sc.cycles.samples = 24
    sc.cycles.use_denoising = False
    sc.render.resolution_x, sc.render.resolution_y = RW, RH
    sc.render.film_transparent = True
    sc.render.image_settings.file_format = 'PNG'; sc.render.image_settings.color_mode = 'RGBA'
    sc.view_settings.view_transform = 'Standard'
    w = bpy.data.worlds.new('W'); sc.world = w; w.use_nodes = True
    w.node_tree.nodes['Background'].inputs[1].default_value = 0.75
    return sc


def opaque(tex):
    out = os.path.join(tempfile.gettempdir(), 'vi_' + hashlib.md5(tex.encode()).hexdigest() + '.png')
    if not os.path.exists(out):
        src = Image.open(tex).convert('RGBA')
        bg = Image.new('RGBA', src.size, TINT); bg.alpha_composite(src); bg.save(out)
    return out


def material(tex, glass, uv_name):
    m = bpy.data.materials.new('M'); m.use_nodes = True
    b = m.node_tree.nodes['Principled BSDF']
    if glass:
        b.inputs['Base Color'].default_value = (*GLASS_RGB, 1)
        b.inputs['Roughness'].default_value = 0.55
        return m
    img = m.node_tree.nodes.new('ShaderNodeTexImage')
    img.image = bpy.data.images.load(opaque(tex)); img.interpolation = 'Closest'
    if uv_name:
        # vehicle meshes carry a second UV layer that can be the active render one; the game
        # samples the diffuse from the first layer
        uv = m.node_tree.nodes.new('ShaderNodeUVMap'); uv.uv_map = uv_name
        m.node_tree.links.new(uv.outputs['UV'], img.inputs['Vector'])
    m.node_tree.links.new(img.outputs['Color'], b.inputs['Base Color'])
    b.inputs['Roughness'].default_value = 0.6
    return m


def is_glass(name):
    n = name.lower()
    return ('window' in n or 'windshield' in n or 'winshield' in n) and 'armor' not in n and 'frame' not in n


def resolve(media, sub, rel, ext):
    p = os.path.join(media, sub, rel)
    if not p.lower().endswith(ext):
        p += ext
    if not os.path.exists(p):
        raise FileNotFoundError(p)
    return p


def render(media, job, out_dir, keep_big):
    sc = scene()
    tex = resolve(media, 'textures', job['tex'], '.png')
    if job.get('standalone'):
        bpy.ops.import_scene.fbx(filepath=resolve(media, 'models_X', job['standalone'], '.fbx'))
        target = [o for o in sc.objects if o.type == 'MESH']
        centre = None
    else:
        fbx = resolve(media, 'models_X', job['vehicle'], '.fbx')
        bpy.ops.import_scene.fbx(filepath=fbx)
        meshes = {o.name: o for o in sc.objects if o.type == 'MESH' and len(o.data.vertices)}
        name = job.get('obj_right') if job.get('obj_right') in meshes else job['obj']
        if name not in meshes:
            raise KeyError(f"{name} not in {fbx}; meshes: {sorted(meshes)}")
        allp = np.array([o.matrix_world @ v.co for o in meshes.values() for v in o.data.vertices])
        centre = mathutils.Vector(((allp.min(0) + allp.max(0)) / 2).tolist())
        target = [meshes[name]]
        # hide rather than delete: parts are parented to a scaled armature, and removing it
        # would move the part away from the transform the camera is framed on
        for o in sc.objects:
            if o not in target:
                o.hide_render = True
    glass = job.get('glass', any(is_glass(o.name) for o in target))
    uvs = target[0].data.uv_layers
    mat = material(tex, glass, uvs[0].name if len(uvs) else None)
    for o in target:
        o.data.materials.clear(); o.data.materials.append(mat)
        for m in o.modifiers:
            m.show_render = False

    pts = np.array([o.matrix_world @ v.co for o in target for v in o.data.vertices])
    pc = mathutils.Vector(((pts.min(0) + pts.max(0)) / 2).tolist())
    c = pts - pts.mean(0)
    w = np.linalg.eigvalsh(c.T @ c)
    # flat = most face area points one way (doors with mirrors/handles still qualify)
    Nm = np.zeros((3, 3))
    for o in target:
        r3 = o.matrix_world.to_3x3()
        for f in o.data.polygons:
            fn = np.array((r3 @ f.normal).normalized()[:])
            Nm += f.area * np.outer(fn, fn)
    nw, nv = np.linalg.eigh(Nm)
    flat = (nw[2] / max(nw.sum(), 1e-12) > 0.6 or w[0] / max(w[1], 1e-12) < 0.08) and not job.get('solid')
    Z = mathutils.Vector((0, 0, 1)); Y = mathutils.Vector((0, 1, 0))
    lname = target[0].name.lower()
    el = math.radians(job.get('elev', ELEV)); az = math.radians(job.get('azim', AZIM))

    if job.get('view'):
        # explicit model-space view: the direction the camera sits in, positive elev = from above
        view = mathutils.Vector(job['view']).normalized()
        up = mathutils.Vector(job.get('up', (0, 0, 1)))
        up = (up - view * view.dot(up)).normalized()
        el = -el
    elif flat and centre is not None:
        # facing from area-weighted face normals: robust to mirrors/handles that skew a
        # vertex-spread estimate
        n = mathutils.Vector(nv[:, 2])
        out = Z if any(k in lname for k in UP_PARTS) else (pc - centre)
        if n.dot(out) < 0: n = -n
        if abs(n.z) > (0.5 if any(k in lname for k in LYING_PARTS) else 0.75):
            up = Y.copy()                                   # lying panel: front at the top
        else:
            up = (Z - n * n.dot(Z)).normalized()            # standing panel: upright
        view = n
    else:
        # solid part: 3/4 from above on its outward side (front-right for standalone)
        side = (pc - centre) if centre is not None else mathutils.Vector((1, -1, 0))
        side.z = 0
        if side.length < 1e-6: side = mathutils.Vector((1, 0, 0))
        side.normalize()
        view = (side + Z * 0.9).normalized()
        up = (Z - view * view.dot(Z)).normalized()
    if job.get('flip_up'):
        up = -up
    axis = view.cross(up).normalized()                      # image-left (camera looks along -view)
    d = mathutils.Quaternion(axis, -el) @ view
    d = mathutils.Quaternion(up, az) @ d
    d.normalize()
    up2 = (up - d * d.dot(up)).normalized()

    rad = max((mathutils.Vector(p) - pc).length for p in pts)
    cam = bpy.data.objects.new('C', bpy.data.cameras.new('C')); cam.data.type = 'ORTHO'
    cam.location = pc + d * rad * 10
    rot = mathutils.Matrix((d.cross(up2) * -1, up2, d)).transposed()  # columns: x=right, y=up, z=back
    cam.matrix_world = mathutils.Matrix.Translation(cam.location) @ rot.to_4x4()
    cam.rotation_euler.rotate_axis('Z', math.radians(job.get('roll', ROLL)))
    cam.data.clip_start = rad * 0.5; cam.data.clip_end = rad * 30
    sc.collection.objects.link(cam); sc.camera = cam
    bpy.context.view_layer.update()

    # key light from the camera's upper left
    cm = cam.matrix_world.to_3x3()
    ldir = (cm @ mathutils.Vector((-0.6, 0.8, 1.0))).normalized()
    sun = bpy.data.objects.new('S', bpy.data.lights.new('S', 'SUN')); sun.data.energy = 3.4
    sun.rotation_euler = (-ldir).to_track_quat('-Z', 'Y').to_euler()
    sc.collection.objects.link(sun)

    inv = cam.matrix_world.inverted()
    cp = [inv @ mathutils.Vector(p) for p in pts]
    xs = [p.x for p in cp]; ys = [p.y for p in cp]
    wv, hv = max(xs) - min(xs), max(ys) - min(ys)
    cam.data.ortho_scale = (wv if wv >= hv * RW / RH else hv) * FIT
    cam.data.shift_x = ((max(xs) + min(xs)) / 2) / cam.data.ortho_scale
    cam.data.shift_y = ((max(ys) + min(ys)) / 2) / cam.data.ortho_scale

    out = os.path.join(out_dir, 'Item_' + job['icon'] + '.png') if out_dir else \
        os.path.join(media, 'textures', 'Item_' + job['icon'] + '.png')
    os.makedirs(os.path.dirname(out), exist_ok=True)
    tmp = out + '.big.png'
    sc.render.filepath = tmp
    bpy.ops.render.render(write_still=True)
    im = Image.open(tmp).convert('RGBA')
    os.remove(tmp)
    if keep_big:
        im.save(out[:-4] + '_big.png')
    im.resize((OW, OH), Image.LANCZOS).save(out)
    return out


def main():
    args = sys.argv[sys.argv.index('--') + 1:] if '--' in sys.argv else sys.argv[1:]
    pos = [a for i, a in enumerate(args) if not a.startswith('--') and (i == 0 or args[i - 1] not in ('--only', '--out-dir'))]
    if len(pos) < 2:
        sys.exit('usage: render_vehicle_icons.py <media> <jobs.json> [--only REGEX] [--out-dir DIR] [--big]')
    media, jobs_path = pos[0], pos[1]
    only = args[args.index('--only') + 1] if '--only' in args else None
    out_dir = args[args.index('--out-dir') + 1] if '--out-dir' in args else None
    jobs = json.load(open(jobs_path))
    if only:
        jobs = [j for j in jobs if re.search(only, j['icon'])]
    for j in jobs:
        print('OK', render(media, j, out_dir, '--big' in args))


main()
