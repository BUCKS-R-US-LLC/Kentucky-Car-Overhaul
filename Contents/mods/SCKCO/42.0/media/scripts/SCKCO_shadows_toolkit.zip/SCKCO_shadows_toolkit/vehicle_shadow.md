# vehicle_shadow.py

Bakes a top-down ground shadow texture for a Project Zomboid vehicle and prints the matching `shadowExtents` / `shadowOffset` values.

Output is deterministic (same inputs and flags give byte-identical PNGs), and shadows are client-side only, so there is nothing to sync in MP.

## Batch mode (everything in a folder, one command)

Put `vehicle_shadow.py`, `blender_top.py` and your `.fbx` files in one folder, open a terminal there and run:

```
python vehicle_shadow.py --batch --fill
```

For each `.fbx` it finds Blender, renders the top view, measures it, picks a texture density and writes `shadows\<name>_shadow.png`. It also writes `shadows\shadows.txt` with the ready-to-paste `shadowExtents`, `shadowOffset` and `textureShadow` lines for every vehicle.

Add `--watch` to leave it running: it regenerates a vehicle whenever its `.fbx` is added or saved. Press Ctrl+C to stop.

| Flag | Default | Description |
|---|---|---|
| `--batch [DIR]` | `.` | Process every `.fbx` in DIR (not recursive). |
| `--watch` | off | Keep running and reprocess new or changed files. |
| `--outdir` | `shadows` | Output folder, relative to DIR. |
| `--blender` | auto | Path to `blender.exe`. Auto-detect checks `--blender`, the `BLENDER` environment variable, `PATH`, then `Program Files\Blender Foundation\Blender *` (highest version) and Steam. |
| `--exclude a b` | `tire wheel` | Skip files whose name contains any of these. Pass `--exclude` with no values to include everything. |
| `--only a b` | none | Only process files whose name contains one of these. |
| `--hide`, `--min-z`, `--front`, `--scale` | see Blender section | Passed through to `blender_top.py`. |
| `--target-ppu` | 64 | Texture density goal. Each vehicle gets the highest density below 2x this that exactly fills its power-of-two size. |
| `--ppu` | auto | Fixed texture density for every vehicle (overrides auto). |
| `--render-ppu` | 112 | Top-view render density. |
| `--keep-top` | off | Keep the intermediate top views in `shadows\_top`. |

Batch uses the flat look (`--soft 0.03`, `--opacity 1`). A failing file is reported and skipped, the rest continue, and the exit code is 1 if any failed. All vehicles in one run share the same `--hide`, `--min-z`, `--front` and `--scale`, so group vehicles that need different values into separate folders or use `--only`.

## Requirements

- Python 3.8+
- `pip install pillow numpy`

## Quick start

```
python vehicle_shadow.py HMMWV.obj -o media/textures/Vehicles/hmmwv_shadow.png --skip glass antenna --min-y 0.25
```

Example output:

```
media/textures/Vehicles/hmmwv_shadow.png  128x256px @ 32 px/unit  body 2.180 x 4.920
shadowExtents = 4.000 8.000,
shadowOffset = 0.000 0.040,
```

Paste the two lines into the vehicle block and point the skin at the texture:

```
vehicle Base.HMMWV
{
    shadowExtents = 4.000 8.000,
    shadowOffset = 0.000 0.040,

    skin
    {
        textureShadow = Vehicles/hmmwv_shadow,
    }
}
```

`textureShadow` placement is from memory. Confirm it against a vanilla vehicle script in `media/scripts/vehicles/` before rolling out.

## Inputs

| Source | Usage | Notes |
|---|---|---|
| `.obj` | `tool.py model.obj -o out.png` | Triangles projected onto the XZ plane (Y up). Extents and offset are derived from the mesh. |
| top-view image | `tool.py top.png -o out.png --size W` | Silhouette from alpha if the image has transparency, otherwise keyed against the background (see below). Auto-cropped to the silhouette bbox. `--size W` derives length from the aspect ratio; `--size W L` stretches to fit. |
| `rect` | `tool.py rect -o out.png --size W L` | Rounded rectangle, for quick placeholders. |

### Generating from a top-view image

Matches the flat, near-opaque look of vanilla-style shadows (hard silhouette, ~1-2 px soft edge, holes preserved where the background shows through).

```
python vehicle_shadow.py TractorTop.png -o media/textures/Vehicles/tractor_shadow.png --size 2.2 --flat --opacity 1 --soft 0.03 --ppu 56
```

- Render the vehicle orthographically from directly above, flat-shaded or solid black, on a uniform background (white, or transparent).
- Opaque images: the background color is the median of the four corner patches. Pixels differing from it by more than `--tol` (max channel distance) become shadow, ramping to full coverage at `2 * tol`. Raise `--tol` if background noise leaks in, lower it if faint parts of the body drop out.
- `--flat` uses a single blur (`--soft`) and ignores `--core`. Edge softness of roughly 1.4% of body width reads like the reference (`--soft 0.03` for a 2.2 wide body).
- The vehicle's front should point toward the top of the image. Use `--flip-v` if it ends up reversed in game.
- Gaps (between cab and trailer, around axles) stay open only if the background is visible through them in the top render.
- Texture size is the body plus padding rounded up to a power of two per axis, and `shadowExtents` is reported for that full canvas. Choose `--ppu` so the body plus padding lands just under a power of two, for example the printed `body` length times `ppu` close to 500 for a 512 px axis, to avoid wasting resolution.

### Generating the top view in Blender

`blender_top.py` renders the transparent top view for you, with exact scale, so `--size` comes straight from the render.

```
blender -b -P blender_top.py -- --import HMMWV.fbx --out top/hmmwv.png --hide antenna --front +Y --ppu 56
blender -b HMMWV.blend -P blender_top.py -- --out top/hmmwv.png --scale 1.0
```

It prints the measured silhouette and the ready-to-run baker command:

```
silhouette: 2.180 x 4.920 script units (front at top)
silhouette center from model origin (right, front): 0.000 0.040
python vehicle_shadow.py top/hmmwv.png -o hmmwv_shadow.png --size 2.180 --flat --opacity 1 --soft 0.03
```

| Flag | Default | Description |
|---|---|---|
| `--out` | required | Output PNG (RGBA, transparent background). |
| `--import` | none | `.fbx` or `.obj` to import into an empty scene. Without it the open `.blend` is used. |
| `--ppu` | 56 | Render pixels per script unit. |
| `--scale` | 1.0 | Script units per Blender unit (the vehicle script's model `scale`). Verify the printed silhouette against the vehicle's real size. |
| `--hide a b ...` | none | Exclude meshes whose object name contains any substring. Meshes with `hide_render` set are always excluded. |
| `--min-z` | none | Cut everything below this Blender Z using the camera far clip. Off by default: it also removes low floors and beds, which leaves trailers hollow. Wheels are part of the real shadow, so normally leave it unset. |
| `--front` | `+Y` | World axis placed at the top of the image: `+Y`, `-Y`, `+X`, `-X`. |
| `--margin` | 0.1 | Border around the bounds, script units. |
| `--samples` | 16 | Cycles samples (edge anti-aliasing). |

- Cycles with a material override is used, so alpha is exact mesh coverage, glass included, and no GPU or OpenGL context is needed (works on CI and headless boxes).
- Armature-driven meshes render in their current pose. Set the rest pose before running.
- The printed center offset is in image axes (right, front) relative to the Blender origin. Treat it as a starting value for `shadowOffset` and calibrate in game.
- FBX importers may apply unit scaling. If the printed silhouette is off by 100x or 0.01x, set `--scale` accordingly.

### Exporting the OBJ

- Export with Y up, and apply transforms so the mesh is in vehicle space.
- Use the same units as the game model. If the vehicle script applies `scale`, pass it as `--scale`.
- The mesh should be the exterior body only. Exclude interior, wheels, glass and antennas via `--skip` or `--min-y`.

## Options

| Flag | Default | Description |
|---|---|---|
| `-o, --out` | required | Output PNG path. Parent dirs are created. |
| `--size W [L]` | none | Body width (and length) in script units. Required for image and `rect` input. Image input accepts width only. |
| `--tol` | 40 | Background key tolerance (0-255) for opaque top-view images. |
| `--flat` | off | Single blur at `--soft`, no contact layer. Hard-silhouette look. |
| `--fill` | off | Fill holes fully enclosed by the silhouette. Use for open-top trailers and beds that render as a hollow outline. Also fills intentional gaps (e.g. between cab and trailer), so leave it off for those. |
| `--pad` | 3x `--soft` | Border around the body in world units before power-of-two rounding. |
| `--scale` | 1.0 | Multiplier applied to OBJ vertices. Match the script's model `scale`. |
| `--ppu` | 32 (auto in batch) | Texture pixels per world unit. |
| `--skip a b ...` | none | Skip OBJ groups (`o`/`g`) or materials (`usemtl`) whose name contains any substring (case-insensitive). |
| `--min-y` | none | Drop faces whose highest vertex is below this height (after `--scale`). Useful for wheels and undercarriage. |
| `--soft` | 0.3 (0.03 in batch) | Penumbra Gaussian sigma in world units. Padding is 3x this, so larger values grow the texture. |
| `--core` | 0.08 | Contact-shadow sigma in world units. Tight, dark band hugging the body. |
| `--opacity` | 0.6 (1.0 in batch) | Overall alpha multiplier (0-1). |
| `--flip-h` / `--flip-v` | off | Mirror the mask horizontally or vertically. |
| `--max-px` | 512 | Hard limit on either texture dimension. Exceeding it is an error, not a silent downscale. |

## How it works

1. Triangles are rasterized at 4x supersampling into a binary mask, centered on the mesh bounds (+Z is image-up).
2. The mask is box-downsampled, then blurred twice: `--soft` (penumbra) and `--core` (contact).
3. Alpha is `max(core, soft) * opacity`, or `soft * opacity` with `--flat`. RGB is black.
4. Texture size is each axis padded by `3 * soft`, then rounded up to a power of two. The printed `shadowExtents` is the pixel size divided by `--ppu`, so the texture maps 1:1 to world scale with no stretching.
5. `shadowOffset` is the mesh bounds center in XZ.

## Calibrating in game

Orientation and offset sign could not be verified outside the game. Test on one vehicle first:

1. Spawn the vehicle and view it from above.
2. Shadow mirrored front-to-back: add `--flip-v`. Mirrored left-to-right: add `--flip-h`.
3. Shadow shifted along the length: check the sign of `shadowOffset` Z and the script's `center` value, since the mesh origin may not equal the vehicle center.
4. Too faint or heavy: adjust `--opacity`. Too wide: lower `--soft`.

Once one vehicle is correct, the same flags apply to the rest of the family sharing the same export convention.

## Batch example (PowerShell)

```
Get-ChildItem models\*.obj | ForEach-Object {
    python vehicle_shadow.py $_.FullName -o "media\textures\Vehicles\$($_.BaseName)_shadow.png" --skip glass antenna --min-y 0.25
}
```

Per-vehicle flag differences belong in a small wrapper script or a batch file rather than in the tool.

## Errors

| Message | Cause | Fix |
|---|---|---|
| `no geometry left after --skip/--min-y filters` | Filters removed every face. | Loosen `--skip` or lower `--min-y`. |
| `NNNxNNNpx exceeds --max-px` | Body plus padding is too large at the chosen `--ppu`. | Lower `--ppu`, lower `--soft`, or raise `--max-px`. |
| `--size is required for image/rect input` | Missing `--size` for image or rect mode. | Pass `--size`. |
| `no silhouette found` | Keying removed everything, or the image has no contrast against its background. | Lower `--tol`, or check that corners are background. |

## Known limits

- Projection is orthographic from above; height is ignored beyond `--min-y` filtering.
- OBJ parsing reads `v`, `f`, `o`, `g` and `usemtl` only. Normals, UVs and other directives are ignored.
- Image input assumes the background touches all four corners. Subjects cropped to the image edge will key incorrectly.
- A single shadow texture is generated per run. Skins that share a body can reuse one texture.
