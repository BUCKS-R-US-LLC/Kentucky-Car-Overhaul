"""Bake a top-down ground shadow texture for a Project Zomboid vehicle.

Single file:
  vehicle_shadow.py model.obj -o out.png            project an OBJ onto XZ (Y up)
  vehicle_shadow.py top.png   -o out.png --size W   top-view image (alpha or keyed bg)
  vehicle_shadow.py rect      -o out.png --size W L rounded rectangle

Batch (FBX -> Blender top view -> shadow, one command):
  vehicle_shadow.py --batch [DIR] [--watch] [--hide glass ...] [--min-z 0.25]

Output: RGBA PNG (black, alpha = shadow), power-of-two dimensions, plus the
shadowExtents / shadowOffset values matching the texture's world coverage.
Output is deterministic so every contributor regenerates identical files.
"""
import argparse
import copy
import glob
import math
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path

import numpy as np
from PIL import Image, ImageChops, ImageDraw, ImageFilter, ImageOps

SS = 4  # supersampling factor for edge quality


def pot(n):
    return 1 << (int(n) - 1).bit_length()


def load_obj(path, scale, skip, min_y):
    verts, tris = [], []
    skipped = False
    group = mtl = ""
    for line in Path(path).read_text(errors="replace").splitlines():
        p = line.split()
        if not p:
            continue
        if p[0] == "v":
            verts.append((float(p[1]) * scale, float(p[2]) * scale, float(p[3]) * scale))
        elif p[0] in ("o", "g", "usemtl"):
            name = " ".join(p[1:]).lower()
            if p[0] == "usemtl":
                mtl = name
            else:
                group = name
            skipped = any(s.lower() in group or s.lower() in mtl for s in skip)
        elif p[0] == "f" and not skipped:
            idx = [int(t.split("/")[0]) for t in p[1:]]
            idx = [i - 1 if i > 0 else len(verts) + i for i in idx]
            for k in range(1, len(idx) - 1):
                tri = (verts[idx[0]], verts[idx[k]], verts[idx[k + 1]])
                if max(v[1] for v in tri) >= min_y:
                    tris.append([(v[0], v[2]) for v in tri])
    if not tris:
        raise RuntimeError("no geometry left after --skip/--min-y filters")
    return np.array(tris)


def load_silhouette(path, tol):
    """Return an 'L' mask cropped to the silhouette bbox.

    Transparent images use alpha. Opaque images are keyed against the median
    color of the four corner patches; coverage ramps from tol to 2*tol of
    max-channel distance so anti-aliased edges survive.
    """
    rgba = np.asarray(Image.open(path).convert("RGBA")).astype(np.int16)
    if rgba[..., 3].min() < 250:
        m = rgba[..., 3]
    else:
        rgb = rgba[..., :3]
        s = 8
        corners = np.concatenate([c.reshape(-1, 3) for c in
                                  (rgb[:s, :s], rgb[:s, -s:], rgb[-s:, :s], rgb[-s:, -s:])])
        bg = np.median(corners, axis=0)
        dist = np.abs(rgb - bg).max(axis=2)
        m = np.clip((dist - tol) * 255 / max(tol, 1), 0, 255)
    m = m.astype(np.uint8)
    ys, xs = np.where(m > 16)
    if not len(xs):
        raise RuntimeError("no silhouette found; adjust --tol or check the background")
    return Image.fromarray(m, "L").crop((xs.min(), ys.min(), xs.max() + 1, ys.max() + 1))


def fill_holes(mask):
    """Fill background regions fully enclosed by the silhouette (open-top boxes, trailers)."""
    b = ImageOps.expand(mask.point(lambda v: 255 if v > 24 else 0), 1, 0)
    ImageDraw.floodfill(b, (0, 0), 128)
    holes = b.point(lambda v: 255 if v == 0 else 0).crop((1, 1, b.width - 1, b.height - 1))
    return ImageChops.lighter(mask, holes)


def bake(a):
    """Write the shadow PNG described by namespace `a`; return (W, H, w, l, cx, cz)."""
    if a.size and len(a.size) > 2:
        raise RuntimeError("--size takes at most two values")
    is_obj = a.src.lower().endswith(".obj")
    sil = None
    if is_obj:
        tris = load_obj(a.src, a.scale, a.skip, a.min_y)
        pts = tris.reshape(-1, 2)
        mn, mx = pts.min(0), pts.max(0)
        w, l = (mx - mn).tolist()
        cx, cz = ((mn + mx) / 2).tolist()
    else:
        if not a.size:
            raise RuntimeError("--size is required for image/rect input")
        if a.src == "rect":
            if len(a.size) != 2:
                raise RuntimeError("rect needs --size W L")
            w, l = a.size
        else:
            sil = load_silhouette(a.src, a.tol)
            w = a.size[0]
            l = a.size[1] if len(a.size) == 2 else w * sil.height / sil.width
        cx = cz = 0.0

    pad = a.pad if a.pad is not None else 3 * a.soft
    W = pot(np.ceil((w + 2 * pad) * a.ppu))
    H = pot(np.ceil((l + 2 * pad) * a.ppu))
    if max(W, H) > a.max_px:
        raise RuntimeError(f"{W}x{H}px exceeds --max-px {a.max_px}; lower --ppu")

    k = a.ppu * SS
    mask = Image.new("L", (W * SS, H * SS), 0)
    if is_obj:
        px = (tris[..., 0] - cx) * k + W * SS / 2
        py = H * SS / 2 - (tris[..., 1] - cz) * k
        d = ImageDraw.Draw(mask)
        for t in range(len(tris)):
            d.polygon([(px[t, i], py[t, i]) for i in range(3)], fill=255)
    else:
        bw, bl = round(w * k), round(l * k)
        ox, oy = (W * SS - bw) // 2, (H * SS - bl) // 2
        if sil is None:
            ImageDraw.Draw(mask).rounded_rectangle(
                [ox, oy, ox + bw - 1, oy + bl - 1], radius=min(bw, bl) * 0.12, fill=255)
        else:
            mask.paste(sil.resize((bw, bl), Image.LANCZOS), (ox, oy))

    if a.fill:
        mask = fill_holes(mask)
    if a.flip_h:
        mask = ImageOps.mirror(mask)
    if a.flip_v:
        mask = ImageOps.flip(mask)
    mask = mask.resize((W, H), Image.BOX)

    soft = np.asarray(mask.filter(ImageFilter.GaussianBlur(max(a.soft * a.ppu, 0.1))), np.float32)
    if a.flat:
        shade = soft
    else:
        core = np.asarray(mask.filter(ImageFilter.GaussianBlur(max(a.core * a.ppu, 0.1))), np.float32)
        shade = np.maximum(core, soft)
    alpha = np.clip(shade * a.opacity, 0, 255).astype(np.uint8)

    rgba = np.zeros((H, W, 4), np.uint8)
    rgba[..., 3] = alpha
    out = Path(a.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    Image.fromarray(rgba, "RGBA").save(out)
    return W, H, w, l, cx, cz


def find_blender(explicit):
    cands = [explicit, os.environ.get("BLENDER"), shutil.which("blender")]
    for root in (os.environ.get("ProgramFiles", r"C:\Program Files"),
                 os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)")):
        found = glob.glob(os.path.join(root, "Blender Foundation", "Blender *", "blender.exe"))
        cands += sorted(found, key=lambda p: [int(x) for x in re.findall(r"\d+", Path(p).parent.name)], reverse=True)
        cands.append(os.path.join(root, "Steam", "steamapps", "common", "Blender", "blender.exe"))
    for c in cands:
        if c and Path(c).is_file():
            return c
    raise RuntimeError("blender not found; pass --blender PATH or set the BLENDER environment variable")


def render_top(blender, script, fbx, png, a):
    cmd = [blender, "-b", "-P", str(script), "--", "--import", str(fbx), "--out", str(png),
           "--ppu", str(a.render_ppu), "--scale", str(a.scale), "--front", a.front]
    if a.hide:
        cmd += ["--hide", *a.hide]
    if a.min_z is not None:
        cmd += ["--min-z", str(a.min_z)]
    r = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace")
    sil = re.search(r"silhouette: ([\d.]+) x ([\d.]+)", r.stdout)
    ctr = re.search(r"center from model origin \(right, front\): (-?[\d.]+) (-?[\d.]+)", r.stdout)
    if r.returncode != 0 or not sil or not ctr or not png.exists():
        tail = "\n".join((r.stdout + r.stderr).splitlines()[-12:])
        raise RuntimeError(f"blender step failed (exit {r.returncode}):\n{tail}")
    return float(sil[1]), float(sil[2]), float(ctr[1]), float(ctr[2])


def auto_ppu(w, l, a):
    """Highest ppu (< 2x target) at which both axes fill, not overshoot, their power-of-two size."""
    pad = a.pad if a.pad is not None else 3 * a.soft
    top = 1 << (a.max_px.bit_length() - 1)
    ratios = []
    for extent in (w + 2 * pad, l + 2 * pad):
        t = min(pot(math.ceil(extent * a.target_ppu)), top)
        ratios.append(t / extent)
    return min(ratios) * 0.999


def write_summary(path, results):
    lines = []
    for stem, r in sorted(results.items()):
        lines += [stem,
                  f"    shadowExtents = {r['ex']:.3f} {r['el']:.3f},",
                  f"    shadowOffset = {r['ox']:.3f} {r['oz']:.3f},",
                  f"    textureShadow = Vehicles/{stem}_shadow,",
                  ""]
    with open(path, "w", newline="") as f:
        f.write("\r\n".join(lines))


def batch_run(a):
    folder = Path(a.batch).resolve()
    outdir = Path(a.outdir) if Path(a.outdir).is_absolute() else folder / a.outdir
    outdir.mkdir(parents=True, exist_ok=True)
    blender = find_blender(a.blender)
    script = Path(__file__).resolve().with_name("blender_top.py")
    if not script.is_file():
        raise RuntimeError(f"{script} not found; keep it next to vehicle_shadow.py")
    print(f"blender: {blender}\noutput:  {outdir}", flush=True)

    def wanted(f):
        s = f.stem.lower()
        return not any(e.lower() in s for e in a.exclude) and (not a.only or any(o.lower() in s for o in a.only))

    def process(f):
        tmp = None if a.keep_top else tempfile.TemporaryDirectory()
        topdir = Path(tmp.name) if tmp else outdir / "_top"
        topdir.mkdir(exist_ok=True)
        try:
            png = topdir / f"{f.stem}_top.png"
            w, l, ox, oz = render_top(blender, script, f, png, a)
            b = copy.copy(a)
            b.src, b.out, b.size = str(png), str(outdir / f"{f.stem}_shadow.png"), [w]
            if b.ppu is None:
                b.ppu = auto_ppu(w, l, b)
            W, H, *_ = bake(b)
            print(f"OK      {f.stem}  body {w:.3f} x {l:.3f}  texture {W}x{H}", flush=True)
            return {"ex": W / b.ppu, "el": H / b.ppu, "ox": ox, "oz": oz}
        finally:
            if tmp:
                tmp.cleanup()

    results, seen, failed = {}, {}, set()
    try:
        while True:
            todo = [f for f in sorted(folder.glob("*.fbx"))
                    if wanted(f) and seen.get(f.name) != f.stat().st_mtime]
            for f in todo:
                seen[f.name] = f.stat().st_mtime
                try:
                    results[f.stem] = process(f)
                    failed.discard(f.name)
                except RuntimeError as e:
                    failed.add(f.name)
                    print(f"FAILED  {f.name}: {e}", flush=True)
            if todo:
                write_summary(outdir / "shadows.txt", results)
                print(f"summary: {outdir / 'shadows.txt'}", flush=True)
            if not a.watch:
                break
            time.sleep(2)
    except KeyboardInterrupt:
        print("stopped")
    if failed:
        print(f"{len(failed)} failed: {', '.join(sorted(failed))}")
    return 1 if failed else 0


def make_parser():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("src", nargs="?", help=".obj, top-view image, or 'rect'")
    p.add_argument("-o", "--out")
    p.add_argument("--size", nargs="+", type=float, metavar="W [L]",
                   help="body width [and length] in script units; image input accepts width only (length from aspect)")
    p.add_argument("--scale", type=float, default=1.0, help="script units per model unit (vehicle script model scale)")
    p.add_argument("--ppu", type=float, default=None, help="texture pixels per world unit (default 32; auto in batch)")
    p.add_argument("--skip", nargs="*", default=[], help="skip OBJ groups/materials containing these substrings")
    p.add_argument("--min-y", type=float, default=-1e9, help="OBJ: drop faces entirely below this height")
    p.add_argument("--tol", type=float, default=40, help="background key tolerance for opaque images (0-255)")
    p.add_argument("--soft", type=float, default=None, help="penumbra sigma, world units (default 0.3; 0.03 in batch)")
    p.add_argument("--core", type=float, default=0.08, help="contact shadow sigma, world units")
    p.add_argument("--flat", action="store_true", help="single blur at --soft, no contact layer (always on in batch)")
    p.add_argument("--fill", action="store_true", help="fill holes fully enclosed by the silhouette (open-top trailers)")
    p.add_argument("--pad", type=float, default=None, help="border around the body, world units (default 3*soft)")
    p.add_argument("--opacity", type=float, default=None, help="overall alpha (default 0.6; 1.0 in batch)")
    p.add_argument("--flip-h", action="store_true")
    p.add_argument("--flip-v", action="store_true")
    p.add_argument("--max-px", type=int, default=512)
    g = p.add_argument_group("batch")
    g.add_argument("--batch", nargs="?", const=".", default=None, metavar="DIR", help="process every .fbx in DIR (default .)")
    g.add_argument("--watch", action="store_true", help="keep running; regenerate when an .fbx is added or saved")
    g.add_argument("--outdir", default="shadows", help="output folder (relative to DIR)")
    g.add_argument("--blender", help="path to blender.exe (auto-detected otherwise)")
    g.add_argument("--exclude", nargs="*", default=["tire", "wheel"], help="skip files whose name contains these")
    g.add_argument("--only", nargs="*", default=[], help="only process files whose name contains one of these")
    g.add_argument("--hide", nargs="*", default=[], help="Blender: exclude objects whose name contains these")
    g.add_argument("--min-z", type=float, default=None, help="Blender: cut geometry below this Z")
    g.add_argument("--front", default="+Y", choices=["+Y", "-Y", "+X", "-X"], help="Blender: world axis at image top")
    g.add_argument("--render-ppu", type=float, default=112, help="Blender top-view render pixels per unit")
    g.add_argument("--target-ppu", type=float, default=64, help="auto texture density target (px per unit)")
    g.add_argument("--keep-top", action="store_true", help="keep the intermediate top views in OUTDIR/_top")
    return p


def main():
    p = make_parser()
    a = p.parse_args()
    batch = a.batch is not None
    if a.soft is None:
        a.soft = 0.03 if batch else 0.3
    if a.opacity is None:
        a.opacity = 1.0 if batch else 0.6
    try:
        if batch:
            a.flat = True
            sys.exit(batch_run(a))
        if not a.src or not a.out:
            p.error("src and -o are required (or use --batch)")
        if a.ppu is None:
            a.ppu = 32
        W, H, w, l, cx, cz = bake(a)
    except RuntimeError as e:
        sys.exit(f"error: {e}")
    print(f"{a.out}  {W}x{H}px @ {a.ppu:g} px/unit  body {w:.3f} x {l:.3f}")
    print(f"shadowExtents = {W / a.ppu:.3f} {H / a.ppu:.3f},")
    print(f"shadowOffset = {cx:.3f} {cz:.3f},")


if __name__ == "__main__":
    main()
