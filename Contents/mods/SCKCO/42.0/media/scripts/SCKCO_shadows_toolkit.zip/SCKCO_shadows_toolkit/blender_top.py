"""Render a transparent orthographic top view of a vehicle for vehicle_shadow.py.

  blender -b [scene.blend] -P blender_top.py -- --out top.png [options]
  blender -b -P blender_top.py -- --import model.fbx --out top.png --hide glass wheel --min-z 0.25

Cycles with a material override is used so the alpha channel is exact mesh
coverage: no GPU/GL context is required and transparent (glass) materials
still cast. Image up = vehicle front (see --front). Blender axes: Z up.
"""
import argparse
import math
import sys
from pathlib import Path

import bpy
import numpy as np
from mathutils import Matrix, Vector

# camera Z rotation that puts the given world axis at the top of the image
FRONT_ROT = {"+Y": 0.0, "-Y": math.pi, "+X": -math.pi / 2, "-X": math.pi / 2}


def parse():
    argv = sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else []
    p = argparse.ArgumentParser()
    p.add_argument("--out", required=True)
    p.add_argument("--import", dest="src", help=".fbx/.obj to import into an empty scene (otherwise uses the open .blend)")
    p.add_argument("--ppu", type=float, default=56, help="render pixels per script unit")
    p.add_argument("--scale", type=float, default=1.0, help="script units per Blender unit (vehicle model scale)")
    p.add_argument("--hide", nargs="*", default=[], help="exclude objects whose name contains these substrings")
    p.add_argument("--min-z", type=float, default=None, help="cut everything below this Blender Z (wheels, undercarriage)")
    p.add_argument("--front", default="+Y", choices=list(FRONT_ROT), help="world axis that points to the top of the image")
    p.add_argument("--margin", type=float, default=0.1, help="border around the bounds, script units")
    p.add_argument("--samples", type=int, default=16)
    return p.parse_args(argv)


def import_model(path):
    ext = Path(path).suffix.lower()
    bpy.ops.wm.read_factory_settings(use_empty=True)
    if ext == ".fbx":
        bpy.ops.import_scene.fbx(filepath=path)
    elif ext == ".obj":
        (bpy.ops.wm.obj_import if hasattr(bpy.ops.wm, "obj_import") else bpy.ops.import_scene.obj)(filepath=path)
    else:
        raise SystemExit(f"error: unsupported import type {ext}")


def main():
    a = parse()
    if a.src:
        import_model(a.src)
    scene = bpy.context.scene

    keep = {o.name for o in scene.objects if o.type == "MESH" and not o.hide_render
            and not any(s.lower() in o.name.lower() for s in a.hide)}
    if not keep:
        raise SystemExit("error: no renderable meshes after --hide filters")
    for o in scene.objects:
        if o.type == "MESH" and o.name not in keep:
            o.hide_render = True

    dg = bpy.context.evaluated_depsgraph_get()
    pts = []
    for o in scene.objects:
        if o.name in keep:
            e = o.evaluated_get(dg)
            pts += [e.matrix_world @ Vector(c) for c in e.bound_box]
    lo = Vector([min(v[i] for v in pts) for i in range(3)])
    hi = Vector([max(v[i] for v in pts) for i in range(3)])
    cx, cy = (lo.x + hi.x) / 2, (lo.y + hi.y) / 2

    theta = FRONT_ROT[a.front]
    along_y = a.front in ("+Y", "-Y")
    w_u = (hi.x - lo.x if along_y else hi.y - lo.y) * a.scale
    l_u = (hi.y - lo.y if along_y else hi.x - lo.x) * a.scale
    res_x = math.ceil((w_u + 2 * a.margin) * a.ppu)
    res_y = math.ceil((l_u + 2 * a.margin) * a.ppu)

    cam_data = bpy.data.cameras.new("shadow_cam")
    cam_data.type = "ORTHO"
    cam_data.sensor_fit = "AUTO"
    cam_data.ortho_scale = max(res_x, res_y) / (a.ppu * a.scale)  # spans the larger image side
    cam_data.clip_start = 0.01
    cam_z = hi.z + 1.0
    cam_data.clip_end = cam_z - (a.min_z if a.min_z is not None else lo.z - 1.0)
    cam = bpy.data.objects.new("shadow_cam", cam_data)
    scene.collection.objects.link(cam)
    cam.location = (cx, cy, cam_z)
    cam.rotation_euler = (0.0, 0.0, theta)
    scene.camera = cam

    mat = bpy.data.materials.new("shadow_mask")
    bpy.context.view_layer.material_override = mat

    r = scene.render
    r.engine = "CYCLES"
    r.resolution_x, r.resolution_y, r.resolution_percentage = res_x, res_y, 100
    r.film_transparent = True
    r.image_settings.file_format = "PNG"
    r.image_settings.color_mode = "RGBA"
    r.image_settings.color_depth = "8"
    r.filepath = str(Path(a.out).resolve())
    scene.view_settings.view_transform = "Standard"
    scene.cycles.device = "CPU"
    scene.cycles.samples = a.samples
    scene.cycles.use_adaptive_sampling = False
    scene.cycles.use_denoising = False
    Path(a.out).resolve().parent.mkdir(parents=True, exist_ok=True)
    bpy.ops.render.render(write_still=True)

    img = bpy.data.images.load(r.filepath)
    arr = np.empty(img.size[0] * img.size[1] * 4, np.float32)
    img.pixels.foreach_get(arr)
    cov = arr.reshape(img.size[1], img.size[0], 4)[..., 3] > 0.06  # rows are bottom-up
    ys, xs = np.where(cov)
    if not len(xs):
        raise SystemExit("error: empty render; check --min-z and --hide")
    sw = (xs.max() - xs.min() + 1) / a.ppu
    sl = (ys.max() - ys.min() + 1) / a.ppu
    v = Vector(((xs.min() + xs.max() + 1) / 2 - img.size[0] / 2, (ys.min() + ys.max() + 1) / 2 - img.size[1] / 2))
    off = Matrix.Rotation(theta, 2).inverted() @ Vector((cx, cy)) * a.scale + v / a.ppu

    print(f"top view: {r.filepath}  {res_x}x{res_y}px @ {a.ppu:g} px/unit")
    print(f"silhouette: {sw:.3f} x {sl:.3f} script units (front at top)")
    print(f"silhouette center from model origin (right, front): {off.x:.3f} {off.y:.3f}")
    print(f"python vehicle_shadow.py {a.out} -o {Path(a.out).stem}_shadow.png --size {sw:.3f} --flat --opacity 1 --soft 0.03")


main()
