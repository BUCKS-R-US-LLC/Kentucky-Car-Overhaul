@echo off
REM ============================================================
REM  gen_all.bat - generate damage + blood for the WHOLE fleet
REM  Put this file (and gen_damage.py) in the Vehicles folder,
REM  then just double-click it. Processes every vehicle subfolder.
REM ============================================================
setlocal
cd /d "%~dp0"

REM ensure deps (only installs if missing; quick after first run)
python -m pip install --quiet numpy scipy pillow 2>nul

echo Generating damage + blood for every vehicle under:
echo   %~dp0
echo.

python "%~dp0gen_damage.py" "%~dp0"

echo.
echo Done. Press any key to close.
pause >nul
