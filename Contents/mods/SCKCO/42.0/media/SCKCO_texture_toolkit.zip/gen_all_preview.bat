@echo off
REM  gen_all_preview.bat - same as gen_all but writes to a PREVIEW folder
REM  so nothing in your mod is overwritten. Check the results, then run
REM  gen_all.bat for real when happy.
setlocal
cd /d "%~dp0"
python -m pip install --quiet numpy scipy pillow 2>nul
set OUT=%~dp0_damage_preview
echo Writing previews to: %OUT%
echo (nothing in your mod is overwritten)
echo.
python "%~dp0gen_damage.py" "%~dp0" --out "%OUT%"
echo.
echo Done. Previews are in _damage_preview\  Press any key to close.
pause >nul
