# SCKCO texture tools - quick usage

Three scripts, all run from your textures folder:
`...\SCKCO\42.0\media\textures\Vehicles`
(the folder with the vehicle subfolders and the masks - NOT media\scripts\vehicles)

- `gen_damage.py`     - damage overlays, blood overlays, and burnt-out wreck skins
- `downscale_masks.py` - shrink masks (and optionally skins) to 1K
- `darken_tires.py`   - flatten + darken wheel textures

Open a command prompt in the Vehicles folder: type `cmd` in the Explorer address bar and
press Enter. In every command below, `.` means "this folder" and recurses through every
vehicle subfolder automatically.

Requirements: Python 3 with numpy, scipy, pillow
(`pip install numpy scipy pillow` once).

---

## Generate BOTH damage and blood (default)

Whole fleet, every vehicle subfolder, in one command:

    python gen_damage.py .

`.` means "this folder". It recurses through every subfolder automatically.

---

## Generate ONLY blood

    python gen_damage.py . --only blood

Writes just the `*Blood.png` overlays, leaves damage textures untouched.

By default blood is kept OFF the hood, doors, and trunk - the game already applies blood
to those panels together with its own damage, so putting it in the overlay too would
double up. Blood lands on the body sides and fenders only. To force it back onto those
panels: add `--blood-hdt`.

---

## Generate ONLY damage

    python gen_damage.py . --only damage

Writes just the `*Damage.png` overlays (glass cracks + dents + scrapes + chips),
no blood.

---

## Apply to ALL vehicles at once

Point at the parent Vehicles folder (the `.` above already does this). It finds every
`*Mask.png` / `*_mask.png` in every subfolder and processes them, printing `[1/N]`
progress per vehicle.

Two-stage stacking damage (Damage1/Damage2):

    python gen_damage.py . --stages

Stage 2 is a guaranteed superset of stage 1 - it contains every mark of stage 1 plus
more, so in-game you swap Damage1 -> Damage2 as the vehicle degrades and damage only ever
accumulates. Stage 1 is softer (glass shows early hairline cracks; blood is pure splatter
dots); stage 2 goes to full crazing and adds smears.

Blood stays a SINGLE centralized `*Blood.png` even with --stages (one blood texture, not
Blood1/Blood2). If you ever want the blood split too: add `--blood-stages`.

Combine with --only:

    python gen_damage.py . --only damage --stages

---

## 1K resolution (save performance)

Two parts, because masks and overlays are separate.

### 1. Downscale your existing masks to 1024 (one time)

    python downscale_masks.py .

This recurses the fleet and shrinks every mask to 1024x1024 in place, using NEAREST so
the zone colours stay exact (verified: no colour corruption). Preview first with:

    python downscale_masks.py . --dry-run

Add `--skins` to also shrink the paint skins:

    python downscale_masks.py . --skins

### 2. Generate 1K overlays

Once masks are 1024, `gen_damage.py .` produces 1024 overlays automatically.

Or force 1K output without permanently changing the masks - downscales each mask to
1024 just for generation:

    python gen_damage.py . --res 1024

---

## Safe preview (don't overwrite anything)

Write to a temp folder that mirrors your subfolders, check it, then run for real:

    python gen_damage.py . --out C:\temp\preview

---

## Per-vehicle tweaks

Drop a `damage.json` in a vehicle's subfolder for custom rules, e.g. no blood on the
hood and trunk:

    { "Vehicle_Foo": { "exclude": ["hood","trunk","doors"] } }

Zone names: glass, doors, lights, bumpers, roof, hood, trunk, body.
It's picked up automatically during the fleet run.


---

## Burnt-out wreck skins (random scorching)

    python gen_damage.py . --only wreck

Writes `<Name>Burnt.png` beside each vehicle - a full opaque replacement skin that covers
the ENTIRE UV (every panel plus all the scattered trim/undercarriage islands), not an
overlay. It starts from the vehicle's real paint (auto-found skin) so the vehicle stays
recognisable, then burns it:

- grey-brown soot-covered metal as the dominant tone, all over the whole UV
- paint peeling to bare grey-brown metal in patches, with dark peel lips
- black burnt edges along panel seams
- heavy scorching on the hood and around the door cutouts (where fire pools)
- orange heat-bloom tints ringing the burned zones (accent, not a wash)
- rust accents and soot drip streaks
- glass scorched dark

Every run randomizes (fire location, severity, rust/soot balance), so different vehicles
burn uniquely in one pass. Re-run with a different `--seed` (e.g. `--seed 7`) to reroll.

Note: output darkness tracks the source skin - a dark paint burns darker, a light paint
lighter. It's tuned to land dark-and-brown on realistic skins.

Preview safely first:

    python gen_damage.py . --only wreck --out C:\temp\wrecks


---

## Darken tires / wheels

Darkens wheel textures (tire + rim) to a flat, uniformly-lit matte look - compresses the
baked-in highlights/shadows toward an even dark grey while keeping enough structure to
read the tread and rim. Preserves transparency.

    python darken_tires.py .

Finds every *wheel*/*tire*/*tyre* PNG in the folder tree and darkens in place. Default is
moderate (dark matte rubber). Adjust darkness:

    python darken_tires.py . --amount 0.4    # subtler
    python darken_tires.py . --amount 0.7    # near-black

Because it targets an absolute tone (not a relative multiply), wheels that started at
different brightnesses all end up at the same uniform level.

Preview safely first:

    python darken_tires.py . --out C:\temp\tires


---

## Troubleshooting

**Some folders are skipped / not generating.** The tool matches any PNG whose name ends
in "mask" (case-insensitive, with or without a separator: `Vehicle_FooMask.png`,
`Vehicle_Foo_mask.png`, `Vehicle_K5mask.png` all work). On each run it prints
`found N mask(s)` - check that against your vehicle count. If a folder has textures but no
recognised mask, it prints a WARNING naming that folder. Any vehicle that errors is
reported at the end and the rest still finish (one failure won't halt the run).

**A vehicle's windows aren't detected as glass.** Mask colours sometimes drift 1-2 values
from the spec (e.g. `128,0,1` instead of `127,0,0`) after a resave. The tool auto-snaps
near-miss colours to the exact zone spec at load, so this is handled - but if a window is
a completely different colour, add a `damage.json` in that vehicle's folder with the right
glass colours.

**Re-running is safe.** Overlay outputs (Damage/Blood/Burnt, incl. the numbered stage
variants) are never mistaken for the vehicle's paint skin on a second run.

---

## Zone reference (for damage.json)

Zone names usable in `glass`, `blood`, `exclude`:
glass, doors, lights, bumpers, roof, hood, trunk, body

You can also give explicit `r,g,b` colours. Example - a vehicle with no blood on the roof
and custom windshield colour:

    { "Vehicle_Foo": { "exclude": ["roof"], "glass": ["127,0,0","0,127,0"] } }
