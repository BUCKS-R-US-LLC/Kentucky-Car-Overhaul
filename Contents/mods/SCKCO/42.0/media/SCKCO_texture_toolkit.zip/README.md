# SCKCO Vehicle Texture Toolkit

A set of Python tools for generating and managing Project Zomboid B42 vehicle textures
in the SCGL/SCKCO Kentucky Car Overhaul style: procedural damage overlays, blood,
burnt-out wreck skins, tire darkening, plus resolution and cleanup utilities.

## What's in here

| Script | Purpose |
|--------|---------|
| `gen_damage.py` | Damage overlays (glass cracks, dents, scrapes, chips), blood spatter, and burnt-out wreck skins. The main tool. |
| `downscale_masks.py` | Shrink masks (and optionally skins) to 1K to save performance. |
| `darken_tires.py` | Flatten + darken wheel textures to a uniform matte look. |
| `cleanup_old_textures.py` | Remove old single-stage `Damage`/`Scratch` textures (keeps `Damage1`/`Damage2`). |
| `gen_all.bat` / `gen_all_preview.bat` | Double-click launchers for the whole fleet. |

## Start here

**`INSTRUCTIONS.md`** has the full usage for every tool with copy-paste commands,
troubleshooting, and the `damage.json` zone reference. Read that.

## Requirements

Python 3 with numpy, scipy, pillow:

    pip install numpy scipy pillow

## Quickest start

Put the scripts in your textures folder
(`...\SCKCO\42.0\media\textures\Vehicles`), open a `cmd` there, and:

    python gen_damage.py .              # damage + blood, whole fleet
    python gen_damage.py . --stages     # two-stage stacking (Damage1/Damage2)
    python gen_damage.py . --only wreck # burnt-out wreck skins

All commands recurse every vehicle subfolder. Preview safely with
`--out C:\temp\preview` before overwriting in place, and keep your GitHub repo committed
as a backup - several of these tools overwrite or delete files.

## Conventions

- All scripts and outputs use CRLF line endings.
- Outputs overwrite in place unless you pass `--out DIR` (which mirrors the subfolder tree).
- Every run prints `[i/N]` progress and a summary; failures on one vehicle don't halt the rest.
