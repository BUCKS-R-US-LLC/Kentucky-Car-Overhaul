"""Remove old single-stage Damage textures and any Scratch textures, now that the mod uses
Damage1/Damage2. DRY-RUN by default - it lists what it would delete and deletes nothing
until you pass --delete.

Removes:
  *Damage.png / *_Damage.png   (single-stage, NO trailing digit)
  anything with 'Scratch' in the name

Keeps (never touched):
  Damage1 / Damage2 (and any Damage<N>), Blood, Burnt, masks, skins, wheels, everything else

Usage:
    python cleanup_old_textures.py .            # dry run - just lists
    python cleanup_old_textures.py . --delete   # actually delete
"""
import os, sys, glob, re, argparse

# match a name ending in "Damage" with NO digit after it (so Damage1/Damage2 are safe).
# handles Vehicle_Foo_Damage and Vehicle_FooDamage (with or without separator).
OLD_DAMAGE = re.compile(r'damage(?!\d)$', re.IGNORECASE)


def is_target(name):
    stem = os.path.splitext(name)[0]
    low = stem.lower()
    if 'scratch' in low:
        return True, 'scratch'
    if OLD_DAMAGE.search(stem):
        return True, 'old single-stage Damage'
    return False, None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('path')
    ap.add_argument('--delete', action='store_true',
                    help='actually delete (default is dry-run: list only)')
    a = ap.parse_args()

    root = a.path if os.path.isdir(a.path) else os.path.dirname(a.path)
    pngs = glob.glob(os.path.join(root, '**', '*.png'), recursive=True)

    hits = []
    for p in sorted(pngs):
        target, why = is_target(os.path.basename(p))
        if target:
            hits.append((p, why))

    if not hits:
        print('Nothing to remove - no old Damage/Scratch textures found under %s' % root)
        return

    print('%s %d file(s):%s\n' % (
        'Deleting' if a.delete else 'Would delete (dry-run)',
        len(hits), '' if a.delete else '  (run with --delete to remove)'))
    for p, why in hits:
        print('  %-55s [%s]' % (os.path.relpath(p, root), why))
        if a.delete:
            os.remove(p)

    print('\n%s %d file(s).' % ('Deleted' if a.delete else 'Would delete', len(hits)))
    if not a.delete:
        print('Re-run with --delete to actually remove them.')


if __name__ == '__main__':
    main()
